
/**
 * The name to use for the barrier in the test cases
 */
#define TEST_BARRIER_NAME "test_barrier"
